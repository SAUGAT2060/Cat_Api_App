package catapp.model;

public class Breed {
    private String name;
    private String origin;
    private String temperament;
    private String description;

    public String getName() { return name; }
    public String getOrigin() { return origin; }
    public String getTemperament() { return temperament; }
    public String getDescription() { return description; }
}
